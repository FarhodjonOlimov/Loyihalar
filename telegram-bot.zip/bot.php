<?php
require 'db.php';

$content = file_get_contents("php://input");
$update = json_decode($content, true);

$chat_id = $update["message"]["chat"]["id"];
$username = $update["message"]["from"]["username"] ?? 'no_username';
$text = $update["message"]["text"];

// Bazaga yozish
$stmt = $pdo->prepare("INSERT INTO messages (chat_id, username, message) VALUES (?, ?, ?)");
$stmt->execute([$chat_id, $username, $text]);

// Javob qaytarish
$reply = [
    'chat_id' => $chat_id,
    'text' => "✅ Xabaringiz bazaga yozildi!"
];

$bot_token = "SIZNING_BOT_TOKENINGIZ";
file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?" . http_build_query($reply));
?>