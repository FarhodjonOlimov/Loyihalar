📦 Telegram Bot + PHP + MySQL

1. `db.php` — MySQL ulanish fayli
2. `bot.php` — Telegram xabarlarini olib bazaga yozadi
3. `telegram_bot.sql` — PhpMyAdmin orqali import qilinadigan SQL fayl
4. `README.txt` — Ushbu ko‘rsatmalar

👉 Ishlatish:
- XAMPPni ishga tushiring (Apache va MySQL)
- `telegram-bot` papkani `htdocs` ichiga joylashtiring
- PhpMyAdmin orqali `telegram_bot.sql` faylini import qiling
- `bot.php` dagi `SIZNING_BOT_TOKENINGIZ` ni haqiqiy token bilan almashtiring
- Ngrok orqali `bot.php` faylga webhook o‘rnating

Tayyor!
