<?php
$host = 'localhost';
$db = 'telegram_bot';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
} catch (PDOException $e) {
    file_put_contents('error_log.txt', $e->getMessage(), FILE_APPEND);
    exit("DB ulanmadi.");
}
?>