from django.contrib import admin

from .models import Librarian

admin.site.register(Librarian)
